<?php
header('Content-Type: text/event-stream');
header('Cache-Control: no-cache');

$switch = file_get_contents('content/callEvent.txt');
if ($switch == "1"){
    $new_data = rand(0, 1000);
    echo "data: refresh \n\n";
    ob_flush();
    
    
    $myfile = fopen("content/callEvent.txt", "w") or die("Unable to open file!");
    $txt = "0";
    fwrite($myfile, $txt);
    fclose($myfile);
}
?>