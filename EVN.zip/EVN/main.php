<!DOCTYPE html>
<html lang="en">
<head>
   <title>Template</title>
</head>
<body>

    <div id=holder>
        <p>
            <?php
            $myfile = fopen("content/0.txt", "r") or die("Unable to open file!");
            echo fread($myfile,filesize("content/0.txt"));
            fclose($myfile);
        ?>
    </p>
    </div>
    <div id="serverData"></div>

<script type="text/javascript">

    if(typeof(EventSource)!=="undefined") {
	   //create an object, passing it the name and location of the server side script
	   var eSource = new EventSource("sendEvent.php");
	   //detect message receipt
	   eSource.onmessage = function(event) {
		  //write the received data to the page
           document.getElementById("serverData").innerHTML = event.data;
           location.reload(true);
		  
	   };
    }
    else {
	   document.getElementById("serverData").innerHTML="Whoops! Your browser doesn't receive server-sent events.";
    }
    
</script>    
    
</body>