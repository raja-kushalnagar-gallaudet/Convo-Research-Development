<?php

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    
    if (!empty($_GET['file'])){
        
        $chooseFile = $_GET['file'];
        
        $def = "Default";
        
        
        if (strcmp($chooseFile, $def) == 0){
            copy("content/default.txt", "content/0.txt");
            
            $myfile = fopen("content/callEvent.txt", "w") or die("Unable to open file!");
            $txt = "1";
            fwrite($myfile, $txt);
            fclose($myfile);
            
            echo("success");
        }
        

        elseif (strcmp($chooseFile, "1") == 0){
            copy("content/1.txt", "content/0.txt");
            
            $myfile = fopen("content/callEvent.txt", "w") or die("Unable to open file!");
            $txt = "1";
            fwrite($myfile, $txt);
            fclose($myfile);
            
            echo("success");
        }

        elseif (strcmp($chooseFile, "2") == 0){
            copy("content/2.txt", "content/0.txt");
            
            $myfile = fopen("content/callEvent.txt", "w") or die("Unable to open file!");
            $txt = "1";
            fwrite($myfile, $txt);
            fclose($myfile);
            
            echo("success");
        }
        
        else{
            echo("Nope");
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <title>Template</title>
</head>
<body>
    
    <form role="form" method = "get" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
              <div class="form-group">
                <label>Choose File</label>
                <select name="file" class="form-control">
                    <option>Default</option>
                    <option>1</option>
                    <option>2</option>
                </select>             
              </div>
              <button type="submit">Submit</button>
            </form>  
    
</body>